 <!--手机导航-->

    <a href="#cd-nav" class="cd-nav-trigger"><i class="fa fa-bars" aria-hidden="true"></i></a>
	<div id="cd-nav" class="cd-nav">
		<div class="cd-navigation-wrapper">

			<div class="cd-half-block">
				<address>
					<ul class="cd-contact-info">
					  <li><a href="<?php $this->options->siteUrl(); ?>">Home</a></li>
                       <?php $this->widget('Widget_Contents_Page_List')
                                  ->parse('<li><a href="{permalink}">{title}</a></li>'); ?>
                    <div style="font-size:10px;"><a href="javascript:void(0);" class="theme-switch"><i class="fa fa-adjust" aria-hidden="true"></i></a></div> 
                    </ul>
				</address>
			</div> <!-- .cd-half-block -->
		</div> <!-- .cd-navigation-wrapper -->
    </div>
   
   <!-- Resource jQuery 导航用-->
<script src="<?php $this->options->themeUrl('js/jquery-2.1.1.js'); ?>"></script>
<script src="<?php $this->options->themeUrl('js/main.js'); ?>"></script> <!-- Resource jQuery -->
   