<?php
/**
* 自定义页面模板
*
* @package custom
*/

$this->need('header.php');?>
<style>
.img-height img {
    width: 80px;
    height: 110px;
    margin-left: 20px;
}
p.space-txt.fz-mid.ellipsis {
    margin-left: 20px;
}
@media screen and (max-width: 420px){#books_dn{display:none;}}
@media (min-width: 420px){#books_sj{display:none;}}/*电脑端隐藏*/
#books {
    display: flex;
    flex-flow: row wrap;
}

#books a:nth-child(6n+0){
    margin-right: 0px;
}

.sort_top {
    border-bottom: 1px dashed #d4d4d4;
}
.sort_top .s_bt {
    padding: 0px;
}
.sort_top a {
    color: #000;
    text-decoration: none;
}
.s_div {
    overflow: hidden;
    height: 100px;
    color: #777;
    font-size: 14px;
    line-height: 20px;
}
.s_title {
    color: #333;
    font-weight: 700;
    font-size: 120%;
}
.s_intro {
    color: #777;
    font-size: 12px;
}
.s_bt img {
    width: 400px;
    height: 100px;
    max-width: 100px;
    padding: 0px 1pc 0px 0px;
}
.img-height.novel {
    width: 100px;
    margin-right: 1pc;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2;
    overflow: hidden;
}
</style>
<?php if ($this->is('category', 'books')): ?>
 <?php $this->books(); ?>
 <div class="main">
     
         <div id="books">
            	<?php while($this->next()): ?>
            <!---->
            <div id="books_dn">
                <div class="item-text img-rectangle" style="" vrcid="scrollItem.d78fa7f">
                    <div class="img-height novel ">
				<a target="_blank" href="<?php $this->permalink() ?>" class="img-wrap ">
					
						<img src="<?php $this->fields->img_link(); ?>" alt="">
	

					</a>
			

			
<div class="novel-info" vrsid="otherLayout.a923420" vrcid="otherLayout.e4f4b17"><p class="space-txt fz-mid ellipsis" vrsid="otherLayoutP1.a923420"><?php $this->title() ?></p>     <h4 class="item-title ">

        </div>
  </div> 
  </div>
            </div>
              <!--dn-->
            <div class="sort_top" id="books_sj"><table><tbody><tr><td class="s_bt">
                <a href="<?php $this->permalink() ?>">
                    <img height="100" width="80" src="<?php $this->fields->img_link(); ?>"></a></td>
                    <td><div class="s_div">
                        <a class="s_title" href="<?php $this->permalink() ?>"><?php $this->title() ?></a>
                         <?php $this->fields->books_author(); ?><br>
                        <a class="s_intro" href="<?php $this->permalink() ?>"> <?php $this->excerpt(132); ?> </a></div></td></tr></tbody></table></div>
            
            <?php endwhile; ?>
         


                    </div>
           <br>
    </div>

<?php endif; ?>

<?php $this->need('footer.php'); ?>
