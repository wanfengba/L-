   <script>
            function showDiv(str) {
                var divs = []; 
                for(var i = 0;i < 4;i++) {
                    divs[i] = document.getElementById("div" + i);
                    divs[i].style.display = "none";
                }
                document.getElementById(str).style.display = "block";               
            }
        </script>
      
            <!-- 书单样式 -->
          <!-- 书单样式开始 -->
         
         <div class="booksdn-content">
          <div class="box_con">
    <div class="con_top">
     
	<?php if($this->is('index')):?><!-- 页面首页时 -->
	<a href="<?php $this->options->siteUrl(); ?>" title="<?php $this->options->title(); ?>">首页</a> &gt;	
	<?php elseif ($this->is('post')): ?><!-- 页面为文章单页时 -->
		<a href="<?php $this->options->siteUrl(); ?>" title="<?php $this->options->title(); ?>">首页</a> &gt; <?php $this->category(); ?> &gt; <?php $this->title(); ?>
	<?php else: ?><!-- 页面为其他页时 -->
		<a href="<?php $this->options->siteUrl(); ?>" title="<?php $this->options->title(); ?>">首页</a> &gt; <?php $this->archiveTitle(' &raquo; ','',''); ?>
	<?php endif; ?>
    </div>
     <!--pc-->
     <div id="post-pc">
    <div id="maininfo">
     <div style="display: flex;">
     <div id="sidebar">
     <div id="fmimg">
      <img alt="<?php $this->title() ?>" src="<?php $this->fields->img_link(); ?>" width="120" height="150">
      <span class="b"></span>
     </div>
    </div>
     <div id="info">
      <h1><?php $this->title() ?></h1>
      <p>作&nbsp;&nbsp;者：<?php $this->fields->books_author(); ?></p>
      <p>最后更新：<?php $this->fields->books_time(); ?></p>
         <div class="abb hangdong">
                    <span onclick="showDiv('div0');" class="xzq">读书笔记</span>
                    <span onclick="showDiv('div1');" class="xzq">本书简介</span>
                    <span onclick="showDiv('div2');" class="xzq">作者介绍</span>
                    <span onclick="showDiv('div3');" class="xzq"></span>
                </div>
     </div></div>
     </div>
     
     </div>
     <!--电脑-->
     <!--手机-->
     <div id="post-dn">
         <div class="detail">
		<img src="<?php $this->fields->img_link(); ?>" alt="<?php $this->title() ?>">
		<p class="name"><strong><?php $this->title() ?></strong></p>
		<p class="author">作者：<?php $this->fields->books_author(); ?></p>
		<p>更新：<?php $this->fields->books_time(); ?></p>
		
		    <div class="abb hangdong  jianju">
                    <span onclick="showDiv('div0');" class="xzq">读书笔记</span>
                    <span onclick="showDiv('div1');" class="xzq">本书简介</span>
                    <span onclick="showDiv('div2');" class="xzq">作者介绍</span>
                    <span onclick="showDiv('div3');" class="xzq"></span>
                </div>
		
	</div>
    </div>
     <!--dn-->
     <div id="intro"></div>
            <!--第二个-->
                    <div id="div1" class="hidden synopsis">
                        
                        <?php $this->content(); ?>
                        <br>
                        </div>
                        
                     <!--第三个-->
                    <div id="div2" class="hidden synopsis">
                    <?php $this->fields->books_introduce(); ?>
                   <br>
                    </div>
                    
                     <!--第四个-->
                     
                    <div id="div3" class="hidden synopsis">等更新</div>
                   <br> 
                 </div>
                       
   <!--第一个-->
                <div class="abb">
                   
                    <div id="div0">
                      <!-- 笔记列表 -->
                   <?php
 $GLOBALS['isLogin'] = $this->user->hasLogin();
 $GLOBALS['rememberEmail'] = $this->remember('mail',true);
function threadedComments($comments, $options)
{
    $commentClass = '';
    if ($comments->authorId) {
        if ($comments->authorId == $comments->ownerId) {
            $commentClass .= ' comment-by-author';
        } else {
            $commentClass .= ' comment-by-user';
        }
    }
    $commentLevelClass = $comments->levels > 0 ? ' comment-child' : ' comment-parent';
    if ($comments->url) {
        $author = '<a href="' . $comments->url . '"' . '" target="_blank"' . ' rel="external nofollow">' . $comments->author . '</a>';
    } else {
        $author = $comments->author;
    }
    ?>
    <li id="li-<?php $comments->theId(); ?>" class="comment comment-body<?php
                                                                if ($comments->levels > 0) {
                                                                    echo ' comment-child';
                                                                    $comments->levelsAlt(' comment-level-odd', ' comment-level-even');
                                                                } else {
                                                                    echo ' comment-parent';
                                                                }
                                                                $comments->alt(' comment-odd', ' comment-even');
                                                                echo $commentClass;
                                                                ?>">
        <div id="<?php $comments->theId(); ?>">
                                   <?php $number=$comments->mail;
                                    if(preg_match('|^[1-9]\d{4,11}@qq\.com$|i',$number)){
                                    echo '<img src="https://q2.qlogo.cn/headimg_dl? bs='.$number.'&dst_uin='.$number.'&dst_uin='.$number.'&;dst_uin='.$number.'&spec=100&url_enc=0&referer=bu_interface&term_type=PC" alt="笔记者头像" height="50" width="50" class="avatar avatar-50 photo"/>'; 
                                    }
                                    elseif (preg_match('|^[a-z]{4,11}@ityinhu\.com$|i',$number)) {
                                      echo '<img src="https://www.ityinhu.com/api/tx/mr.jpg" height="50" width="50" class="avatar avatar-50 photo" alt="笔记者头像"/>';
                                    } 
                                    else{
                                    echo '<img src="https://www.ityinhu.com/api/tx/api.php" height="50" width="50" class="avatar avatar-50 photo" alt="笔记者头像"/>';
                                    }
                                    ?>
            <div class="comment_main">
            <div class="comment_author"><?php echo $author ?>         <?php
					if ($comments->authorId) {
						if ($comments->authorId == $comments->ownerId) {
							_e(' <span class="comment_admin"><span class="comment_admin_tip">博主</span></span> ');
						}
					}
					?>
                    <?php if ($comments->status != 'approved'): ?>
                        <span class="comment_ds"><i original-title="待审笔记" class="iconfont iconyellow"></i></span>
                    <?php endif; ?></div>
            <div class="comment_excerpt match_color">
                <?php $comments->content(); ?>
               
            </div>
            </div>
        </div>
        <?php if ($comments->children) { ?><div class="comment-children"><?php $comments->threadedComments($options); ?></div><?php } ?>
    </li>
<?php } ?>

<div id="comments" class="gen">
    <?php $this->comments()->to($comments); ?>

    <?php if ($this->allow('comment')) : ?>
        <div id="<?php $this->respondId(); ?>" class="respond">

            <form method="post" action="<?php $this->commentUrl() ?>" id="comment-form1" role="form" class="new_comment_form" >
                <div class="comment-inputs">
                    <?php if ($this->user->hasLogin()) : ?>
                    <?php if($this->user->hasLogin()): ?>
                        <p><?php _e('登录身份: '); ?><a href="<?php $this->options->profileUrl(); ?>"><?php $this->user->screenName(); ?></a>. <a href="<?php $this->options->logoutUrl(); ?>" title="Logout"><?php _e('退出'); ?> &raquo;</a></p>
                    <?php else : ?>
                        <div class="commt-name"><input type="text" name="author" id="comment-name" class="text" placeholder="<?php _e('名称'); ?>" value="<?php $this->remember('author'); ?>" required /></div>
                        <div class="commt-email"><input type="email" name="mail" id="comment-mail" class="text" placeholder="<?php _e('邮箱'); ?>" value="<?php $this->remember('mail'); ?>" <?php if ($this->options->commentsRequireMail) : ?> required<?php endif; ?> /></div>
                        <div class="commt-web"><input type="url" name="url" id="comment-url" class="text" placeholder="<?php _e('网址'); ?>" value="<?php $this->remember('url'); ?>" <?php if ($this->options->commentsRequireURL) : ?> required<?php endif; ?> /></div>
                    <?php endif; ?>
                </div>
                <div class="comment-editor">
                    <textarea name="text" id="textarea" placeholder="撰写笔记" class="textarea textarea_box OwO-textarea" required onkeydown="if((event.ctrlKey||event.metaKey)&&event.keyCode==13){document.getElementById('submitComment').click();return false};"><?php $this->remember('text'); ?></textarea>
                </div>
                <div class="comment-buttons">
                
                    <div class="right">
                        <button id="submitComment" type="submit" class="submit match_color_b"><?php _e('发表笔记'); ?></button>
                    </div>
<?php endif ; ?>
            
                </div>
            </form>
             <h4 class="com_h4">笔记<sup style="font-size:x-small;margin-left: 5px;"><?php $this->commentsNum(_t('暂无笔记'), _t('有一条笔记'), _t('共 %d 条笔记')); ?></sup></h4>
        </div>
    <?php else : ?>
         <span class="sortbar"><span><center>🤗这里不能写笔记<sup style="font-size: x-small;margin-left: 5px;"><?php $this->commentsNum(_t('暂无笔记'), _t('有一条笔记'), _t('共 %d 条笔记')); ?></sup></center></span></span>
    <?php endif; ?>
    <div class="comments_lie">
    <?php if ($comments->have()) : ?>
        <?php $comments->listComments(); ?>
        <div class="nav-page">
        <?php $comments->pageNav('<i class="iconfont iconarrow-left-bold"></i>', '<i class="iconfont iconarrow-right-bold"></i>', 3, '...', array('wrapTag' => 'div', 'wrapClass' => 'comments-navigator', 'itemTag' => 'li', 'textTag' => 'span', 'currentClass' => 'current', 'prevClass' => 'prev', 'nextClass' => 'next')); ?>
        </div>
    <?php endif; ?>
</div>
</div>

<?php if ($this->allow('comment')) : ?>

<?php endif; ?>
<style>
textarea#textarea {
   width: 100%;
    height: 100px;
    font-size: inherit;
    outline: none;
    outline: none;
    border: 0;
    border-radius: 4px;
    width: 100%;
    padding: .375rem .75rem;
    min-height: 80px;
    line-height: 1.825;
    display: block;
    background-color: #f0f3f8;
    overflow: auto;
    resize: none;
    font-size: 14px;
    font-weight: 400;
    font-family: inherit;
}
#submitComment {
    border: 0;
    padding: 8px 16px;
    border-radius: 4px;
    font-size: 14px;
    color: #fff;
    background: #000;
    -webkit-transition: all .3s ease;
    -moz-transition: all .3s ease;
    -ms-transition: all .3s ease;
    -o-transition: all .3s ease;
}
  .xzq span{
                cursor: pointer;
            }
           
           .abb div>.abb div{
                border: 1px solid black;
                width: 400px;
                height: 300px;
            }
           .abb1 div>.abb1 div{
                border: 1px solid black;
                width: 400px;
                height: 300px;
            }
            .hidden{
                display: none;
            }
            .abb .xzq {
          padding: 10px 0px;
          font-size: 14px;
          background: #cccccc;
          border-radius: 50px;
}
.abb1 .xzq {
          padding: 10px 0px;
    font-size: 14px;
    background: #cccccc;
    border-radius: 50px;
}
    .booksdn-content.box_con {
    border: 2px solid #1aa2b0;
    overflow: hidden;
    width: 976px;
    margin: 10px auto;
}
    .booksdn-content .con_top{
    border-bottom: #1aa2b0 1px solid;
    text-align: left;
    padding: 0 10px;
    line-height: 40px;
    height: 40px;
}
   .con_top a {
    color: #1aa2b0;
    text-decoration: none;
}

    .booksdn-content #info {
    padding: 10px;
    margin: 10px;
    font-size: 15px;
}
.booksdn-content #info h1 {
    font-size: 28px;
    font-weight: 700;
    overflow: hidden;
    margin: auto;
    padding: 1px;
    
}
    .booksdn-content #info p {
    /*height: 25px; */
    line-height: 25px;
    padding-top: 2px;
    width: 350px;
    /* margin: auto; */
    overflow: hidden;
    /* float: left;*/
    
}
    .booksdn-content #intro {
    
    overflow: hidden;
    line-height: 150%;
    border-top: 1px dashed #C8C7BC;
    padding: 10px;
    font-size: 13px;
}
    .booksdn-content #sidebar {
    
    width: 140px;
    text-align: left;
}
    .booksdn-content #fmimg {
    
    width: 126px;
    margin: 12px;
    padding: 12px;
    position: relative;
}
    .booksdn-content #fmimg img {
    border: medium;
    height: 150px;
    width: 120px;
    margin: 3px;
}
.abb.hangdong.jianju {
    margin-top: 2pc;
}
    .booksdn-content .detail {
    padding: 10px;
    height: 150px;
    
}
    .booksdn-content .detail img {
    float: left;
    margin: 0 15px 0 5px;
    margin-right: 10px;
    padding: 1px;
    width: 108px;
    height: 140px;
    border: 1px solid #e5e5e5;
}
    .booksdn-content.detail p.name {
    height: 32px;
    font-size: 20px;
    line-height: 32px;
}
#fmimg img{
    margin-top: 1pc;
}
   /*书介绍手机电脑端列表*/
@media (min-width: 40em){#post-dn{display:none;}}
@media (max-width: 40em){#post-pc{display:none;}}
@media (max-width: 40em){div#div1{padding-top: 1PC;}}
@media (max-width: 40em){div#div2{padding-top: 2PC;}}
</style>