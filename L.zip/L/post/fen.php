

    <div class="post-copyright">
   
    <p class="copyright-item">
    <span>分享:</span>
    <span>
    
    <a href="//www.linkedin.com/shareArticle?url=<?php $this->permalink() ?>&amp;title=<?php $this->title() ?>" target="_blank" title="Share on LinkedIn">
    <i class="fa fa-linkedin-square" aria-hidden="true"></i>
    </a>
    
    <a href="//vk.com/share.php?url=<?php $this->permalink() ?>&amp;title=<?php $this->title() ?>" target="_blank" title="Share on VKontakte ">
    <i class="fa fa-vk" aria-hidden="true"></i>
    </a>
    <a href="//service.weibo.com/share/share.php?url=<?php $this->permalink() ?>&amp;appkey=&amp;title=<?php $this->title() ?>" target="_blank" title="Share on Douban ">
    <i class="fa fa-weibo" aria-hidden="true"></i>
    </a>
    </span>
    </p>
</div>

<script>
// 获取弹窗
var modal = document.getElementById('myModal');
 
// 打开弹窗的按钮对象
var btn = document.getElementById("myBtn");
 
// 获取 <span> 元素，用于关闭弹窗
var span = document.querySelector('.close');
 
// 点击按钮打开弹窗
btn.onclick = function() {
    modal.style.display = "block";
}
 
// 点击 <span> (x), 关闭弹窗
span.onclick = function() {
    modal.style.display = "none";
}
 
// 在用户点击其他地方时，关闭弹窗
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>