 <div class="post">
   <article class="index-post">
       <div style="display: flex;justify-content: space-between;">
        <a class="index_title" href="<?php $this->permalink() ?>" style="
        text-decoration: none;
        letter-spacing: 1px;
        font-size: 1.5rem;
        margin-bottom: 0.5pc;">
           <div class="tooltip"><?php $this->title() ?><span class="tooltiptext">这里是相册</span></div> 
        </a> <!-- 文章标题 -->
        <span style="
        font-size: 12px;
        font-weight: 400;
        align-items: center;
        margin-bottom: 1pc;">
            <?php $this->date('Y年m月d日'); ?><!-- 文章时间 -->
        </span>
       </div>
    </article>
    
    <article id="index-post">
       <div style="display: flex;flex-direction: column;">
        <a class="index_title" href="<?php $this->permalink() ?>" style="
        text-decoration: none;
        letter-spacing: 1px;
        font-size: 1.5rem;
        margin-bottom: 0.5pc;">
            <div class="tooltip"><?php $this->title() ?><span class="tooltiptext">这里是相册</span></div> 
        </a> <!-- 文章标题 -->
        <span style="
        padding-top: 10px;
        font-size: 12px;
        font-weight: 400;
        align-items: center;
        margin-bottom: 1pc;">
            <?php $this->date('Y年m月d日'); ?><!-- 文章时间 -->
        </span>
      </div>
      </div>
    </article>