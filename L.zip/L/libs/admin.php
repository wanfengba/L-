<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
// 主题设置
function themeConfig($form) {
// 图片设置
    $toutu = new Typecho_Widget_Helper_Form_Element_Text('toutu', NULL, NULL, _t('顶部图片'), _t('出现在首页文章头部'));
 $form->addInput($toutu);
// 友链设置
    $Links = new Typecho_Widget_Helper_Form_Element_Textarea('Links', NULL, NULL, _t('链接列表（注意：切换主题会被清空，注意备份！）'), _t('按照格式输入链接信息，格式：<br><strong>链接名称（必须）,链接地址（必须）,链接描述,logo链接</strong><br>不同信息之间用英文逗号“,”分隔，例如：<br><strong>枯木逢春,https://wfvp.cc/,再腐朽的木头,也会有逢春的那一天吧.,https://q1.qlogo.cn/g?b=qq&amp;nk=171394827&amp;s=640</strong><br>若中间有暂时不想填的信息，请留空，例如暂时不想填写链接描述：<br><strong>枯木逢春,https://wfvp.cc/,,https://q1.qlogo.cn/g?b=qq&amp;nk=171394827&amp;s=640</strong><br>多个链接换行即可，一行一个.'));
    $form->addInput($Links);
}
