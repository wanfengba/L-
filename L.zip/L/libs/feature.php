<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
class feature {

	//表情解析
    public static function parseContent($text, $widget, $lastResult)
    {
        $text = empty($lastResult) ? $text : $lastResult;
        if ($widget instanceof Widget_Abstract_Comments) {
            $text = Shortcode::parseBiaoQing($text);
        }
        return $text;
    }

    /**
     * 泡泡表情回调函数
     *
     * @return string
     */
    public static function parsePaopaoBiaoqingCallback($match)
    {
        return '<img class="biaoqing paopao" src="' . ('https://cdn.jsdelivr.net/gh/zetheme/pigeon/OWO/biaoqing/paopao/') . str_replace('%', '', urlencode($match[1])) . '_2x.png" height="30" width="30">';
    }

    /**
     * 阿鲁表情回调函数
     *
     * @return string
     */
    public static function parseAruBiaoqingCallback($match): string
    {
        return '<img class="biaoqing alu" src="' . ('https://cdn.jsdelivr.net/gh/zetheme/pigeon/OWO/biaoqing/aru/') . str_replace('%', '', urlencode($match[1])) . '_2x.png">';
    }

    /**
     * 蛆音娘表情回调函数
     *
     * @return string
     */
    public static function parseQuyinBiaoqingCallback($match): string
    {
        return '<img class="biaoqing quyin" src="' . ('https://cdn.jsdelivr.net/gh/zetheme/pigeon/OWO/biaoqing/quyin/') . str_replace('%', '', urlencode($match[1])) . '.png">';
    }

    public static function indexTheme($path = '')
    {
        Helper::options()->themeUrl($path);
    }
    
    public static function addButton()
    {
        echo '<script src="https://at.alicdn.com/t/font_2497854_ihvgflwhx5.js"></script>';
        echo '<script src="//at.alicdn.com/t/font_2663042_vn1iwvwmmri.js"></script>';
        
        echo '<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/zetheme/pigeon/OWO/OwO.min.css"/>';
        echo '<script src="';self::indexTheme('/js/editor.js');echo '"></script>';
        echo '<script src="https://cdn.jsdelivr.net/gh/zetheme/pigeon/OWO/OwO.js"></script>';
        echo '<style>#custom-field textarea,#custom-field input{width:100%}
        @media screen and (max-width:767px){	
            .comment-info-input{flex-direction:column;}
            .comment-info-input input{max-width:100%;margin-top:5px}
            #comments .comment-author .avatar{
                width: 2.5rem;
                height: 2.5rem;
            }
        }
        .wmd-button-row{height:unset}
        .icon {
           width: 1.2em; height: 1.2em;
           vertical-align: -0.15em;
           fill: currentColor;
           overflow: hidden;
        }
        .wmd-button {color: #9e9e9e;}
        .OwO span {
            background: none!important;
            width: unset!important;
            height: unset!important;
        }
        </style>';
    }
}

