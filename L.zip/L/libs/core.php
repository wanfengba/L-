<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
class core{


    public static function parseContentPublic($content)
    {
        return $content;
    }







    
    /**
     * 输入内容之前做一些有趣的替换+输出文章内容
     *
     * @param $obj
     * @param $status
     * @return string
     */
    public static function postContent($obj, $status)
    {
        $content = $obj->content;
            $db = Typecho_Db::get();
            $sql = $db->select()->from('table.comments')
                ->where('cid = ?', $obj->cid)
                ->where('status = ?', 'approved')
                ->where('mail = ?', $obj->remember('mail', true))
                ->limit(1);
            $result = $db->fetchAll($sql);//查看评论中是否有该游客的信息

            //文章中部分内容隐藏功能（回复后可见）
            if ($status || $result) {
                $content = preg_replace("/\[hide\](.*?)\[\/hide\]/sm", '<div class="reply2view">$1</div>', $content);
            } else {
                $content = preg_replace("/\[hide\](.*?)\[\/hide\]/sm", '<div class="reply2view">' . ("此处内容需要评论回复后（审核通过）方可阅读。") . '</div>', $content);
            }

            $content = core::parseContentPublic($content);
        
        return trim($content);
    }




    /**
     * 输出文章摘要
     * @param $content
     * @param $limit 字数限制
     * @return string
     */
    public static function excerpt($content, $limit)
    {

        if ($limit == 0) {
            return "";
        } else {
            $content = self::returnExceptShortCodeContent($content);
            if (trim($content) == "") {
                return ("暂时无可提供的摘要");
            } else {
                return Typecho_Common::subStr(strip_tags($content), 0, $limit, "...");
            }
        }
    }


    /**
     * 获取匹配短代码的正则表达式
     * @param null $tagnames
     * @return string
     * @link https://github.com/WordPress/WordPress/blob/master/wp-includes/shortcodes.php#L254
     */
    public static function get_shortcode_regex($tagnames = null)
    {
        global $shortcode_tags;
        if (empty($tagnames)) {
            $tagnames = array_keys($shortcode_tags);
        }
        $tagregexp = join('|', array_map('preg_quote', $tagnames));
        // WARNING! Do not change this regex without changing do_shortcode_tag() and strip_shortcode_tag()
        // Also, see shortcode_unautop() and shortcode.js.
        // phpcs:disable Squiz.Strings.ConcatenationSpacing.PaddingFound -- don't remove regex indentation
        return
            '\\['                                // Opening bracket
            . '(\\[?)'                           // 1: Optional second opening bracket for escaping shortcodes: [[tag]]
            . "($tagregexp)"                     // 2: Shortcode name
            . '(?![\\w-])'                       // Not followed by word character or hyphen
            . '('                                // 3: Unroll the loop: Inside the opening shortcode tag
            . '[^\\]\\/]*'                   // Not a closing bracket or forward slash
            . '(?:'
            . '\\/(?!\\])'               // A forward slash not followed by a closing bracket
            . '[^\\]\\/]*'               // Not a closing bracket or forward slash
            . ')*?'
            . ')'
            . '(?:'
            . '(\\/)'                        // 4: Self closing tag ...
            . '\\]'                          // ... and closing bracket
            . '|'
            . '\\]'                          // Closing bracket
            . '(?:'
            . '('                        // 5: Unroll the loop: Optionally, anything between the opening and closing shortcode tags
            . '[^\\[]*+'             // Not an opening bracket
            . '(?:'
            . '\\[(?!\\/\\2\\])' // An opening bracket not followed by the closing shortcode tag
            . '[^\\[]*+'         // Not an opening bracket
            . ')*+'
            . ')'
            . '\\[\\/\\2\\]'             // Closing shortcode tag
            . ')?'
            . ')'
            . '(\\]?)';                          // 6: Optional second closing brocket for escaping shortcodes: [[tag]]
        // phpcs:enable
    }

    //短代码排除
    public static function returnExceptShortCodeContent($content)
    {
        $v = array(
            'button', 'cid', 'login', 'login', 'hide', 'tabs', 'collapse', 'tip', 'photos', 'mp3',
            'video', 'bilibili', 'colour', 'danger', 'font', 'img','test-del',
        );

        foreach ($v as $l) {
            if (strpos($content, '[' . $l) !== false) {
                $pattern = self::get_shortcode_regex(array($l));
                $content = preg_replace("/$pattern/", '', $content);
            }
        }
        $content = preg_replace('/\$\$[\s\S]*\$\$/sm', '', $content);
        return $content;
    }
}