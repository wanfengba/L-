<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>

<article class="post-warp">
    <header class="post-header">
     <div class="header_img"><img src="<?php $this->options->toutu(); ?>"></div>
    </header> 

       
<?php if($this->category == "photos"): ?> <!-- 相册样式 -->
<?php $this->need('post/photos.php'); ?>
<?php elseif($this->category == "books"): ?><!-- 书单样式 -->
<?php $this->need('post/books.php'); ?>
<?php else: ?><!-- 默认样式 -->
 <!--标题-->
                    <div style="display: flex;justify-content: space-between;">
                    <div class="post_title" style="display: flex;">
                        <h1><?php $this->title() ?></h1>   
                        <span style="font-size: x-small;
                                     margin-left: 5px;"><?php get_post_view($this) ?> 阅读</span>
                    </div>
                    <!-- 打开弹窗按钮 -->
                    <div id="myBtn">💰</div>
                    <!-- 弹窗 -->
                    <div id="myModal" class="modal">
                      <!-- 弹窗内容 -->
                      <div class="modal-content">
                        <span class="close">&times;</span>
                        <center style="padding-top: 50px;font-size: small;">扫码打赏<br>你说多少就多少</center>
                        <center><img src="https://cdn.jsdelivr.net/gh/wanfengba/tuping/usr/uploads/2021/09/846577408.png"width="150px"></center>
                         <center><p style="color: #b5b5b5;font-size: small;">感谢您的支持，我会继续努力的!</p></center>
                         <center><p style="color: red;font-size: small;">温馨提醒：不影响用户阅读，暗黑模式图片会变暗</p></center>
                      </div>
                    </div>
                    </div>
    
     <!--内容-->
     <div class="post-content active">
      <?php echo core::postContent($this,$this->user->hasLogin());?>
    </div>
    
    <div class="post_date"><?php echo date('Y 年 m 月 d 日 H:i:s' , $this->modified); ?></div>
    
     <?php printTag($this); ?>
    
    <!--信息-->
    <?php $this->need('post/fen.php'); ?>
    <?php $this->need('comments.php'); ?>
<?php endif; ?>


   
</article>
<?php $this->need('footer.php'); ?>
