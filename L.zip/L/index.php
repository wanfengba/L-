<?php
/**
 * 闲的没事干，想体验一把pjax
 * 瞎搞的，说干就干，超简约
 * @package L
 * @author 枯木逢春
 * @version 1.0
 * @link https://www.ucuser.cn/note/12.html
 */
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
 $this->need('header.php');
 ?>
<div class="header_img"><img src="<?php $this->options->toutu(); ?>"></div>
  <!-- 内容 --> 
  <?php if ($this->have()): ?>
    <?php while($this->next()): ?>
<?php if($this->fields->article_type == "photos") { ?><!-- 相册样式 -->

<?php } elseif ($this->fields->article_type == "books") { ?><!-- 书单样式 -->
<?php $this->need('index/books.php'); ?>
<?php } else {?><!-- 默认样式 -->
        <div class="post">
   <article class="index-post">
       <div style="display: flex;justify-content: space-between;">
        <a class="index_title" href="<?php $this->permalink() ?>" style="
        text-decoration: none;
        letter-spacing: 1px;
        font-size: 1.5rem;
        margin-bottom: 0.5pc;">
            <div class="tooltip"><?php $this->title() ?><span class="tooltiptext">这里是文章</span></div> 
        </a> <!-- 文章标题 -->
        <span style="
        font-size: 12px;
        font-weight: 400;
        align-items: center;
        margin-bottom: 1pc;">
            <?php $this->date('Y年m月d日'); ?><!-- 文章时间 -->
        </span>
       </div>
       <!--判断文章是否加密-->
<?php if($this->hidden||$this->titleshow): ?>
<!--如果加密，输出自定义的表单格式-->
<form action="<?php echo Typecho_Widget::widget('Widget_Security')->getTokenUrl($this->permalink); ?>" method="post">
<div class="form-group mb-3">
<label>突然就有了小秘密</label>
<div class="input-group">
<input  type="password" class="text" name="protectPassword" class="form-control" placeholder="请输入密码" aria-label="请输入密码">
<input type="hidden" name="protectCID" value="<?php $this->cid(); ?>" />
<div class="input-group-append">
<button class="btn btn-primary" type="submit">提交</button>
</div>
</div>
</div>
</form>
<?php else: ?>
<!--如果未加密，输出文章内容-->
<?php endif;?>
    </article>
    <article id="index-post">
       <div style="display: flex;flex-direction: column;">
        <a class="index_title" href="<?php $this->permalink() ?>" style="
        text-decoration: none;
        letter-spacing: 1px;
        font-size: 1.5rem;
        margin-bottom: 0.5pc;">
             <div class="tooltip"><?php $this->title() ?><span class="tooltiptext">这里是文章</span></div> 
        </a> <!-- 文章标题 -->
             <!--判断文章是否加密-->
<?php if($this->hidden||$this->titleshow): ?>
<!--如果加密，输出自定义的表单格式-->
<form action="<?php echo Typecho_Widget::widget('Widget_Security')->getTokenUrl($this->permalink); ?>" method="post" id"index_mm">
<div class="form-group mb-3">
<label>突然就有了小秘密</label>
<div class="input-group1">
<input  type="password" class="text" name="protectPassword" class="form-control" placeholder="请输入密码" aria-label="请输入密码">
<input type="hidden" name="protectCID" value="<?php $this->cid(); ?>" />
<div class="input-group-append1">
<button class="btn btn-primary" type="submit">提交</button>
</div>
</div>
</div>
</form>
<?php else: ?>
<!--如果未加密，输出文章内容-->
<?php endif;?>
        <span style="
        padding-top: 10px;
        font-size: 12px;
        font-weight: 400;
        align-items: center;
        margin-bottom: 1pc;">
            <?php $this->date('Y年m月d日'); ?><!-- 文章时间 -->
        </span>
      </div></div>
    </article>

     <?php }?>
<?php endwhile; ?>   

    <?php else: ?>这里还没有文章噢！<?php endif; ?>
    
    <ul class="pagination">
        <?php $this->pageLink('下一页','next'); ?>
    </ul>

     

<?php $this->need('footer.php'); ?>
