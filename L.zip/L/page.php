<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>
<article class="post-warp">
    <header class="post-header">
        <div class="header_img"><img src="<?php $this->options->toutu(); ?>"></div>
    <div class="post-meta">
         <div class="post_title" style="display: flex;">
                        <h1><?php $this->title() ?></h1>   
                        <span style="font-size: x-small;
                                     margin-left: 5px;"><?php get_post_view($this) ?> 阅读</span>
                    </div>
    </div>
    </header>
    <div class="page-content">
        <?php $this->content(); ?>
    </div>
</article>
<?php $this->need('comments.php'); ?>
<?php $this->need('footer.php'); ?>