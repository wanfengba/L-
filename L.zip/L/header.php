<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<!DOCTYPE html>
<html lang="zh">
<head>
    <meta http-equiv="content-type" content="text/html;charset=utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1">
	<meta name="renderer" content="webkit">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
	<title><?php if ($this->is('index')): ?><?php if ($this->options->SiteSubtitle): ?><?php $this->options->title(); ?> - <?php $this->options->SiteSubtitle(); ?><?php else: ?><?php $this->options->title(); ?><?php endif; ?><?php else: ?><?php $this->archiveTitle(array('category'  =>  _t('分类 %s 下的文章'),'search'    =>  _t('包含关键字 %s 的文章'),'tag' =>  _t('标签 %s 下的文章'),'author'  =>  _t('%s 发布的文章')), '', ' - '); ?><?php $this->options->title(); ?><?php endif; ?></title>
    <?php $this->header('commentReply='); ?>
    <link rel="stylesheet" href="<?php $this->options->themeUrl('css/pjax.css'); ?>"><!--pjax-->
    <link rel="stylesheet" href="<?php $this->options->themeUrl('css/style.css'); ?>"><!--全局-->
    <link rel="stylesheet" href="<?php $this->options->themeUrl('css/post.css'); ?>"><!--文章装修-->
    <link href="//netdna.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet"><!--图标-->
    <link rel="stylesheet" href="<?php $this->options->themeUrl('css/nav.css'); ?>"><!--导航-->
    <link rel="stylesheet" href="<?php $this->options->themeUrl('OwO/OwO.min.css'); ?>">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/wanfengba/tuping/prism.css">
    <link href="https://cdn.jsdelivr.net/gh/wanfengba/tuping/jquery.lighter.css" rel="stylesheet" type="text/css" /><!--灯箱-->
    
	<?php if ($this->options->Custom_css): ?>
		<!-- 自定义css -->
		<style type="text/css">
			<?php $this->options->Custom_css(); ?>
		</style>
	<?php endif; ?>
</head>
<body class="">
    <div class="wrapper">
        <nav class="navbar">
            <div class="container">
                <div class="menu navbar-right">
                   <?php $this->need('sidebar.php'); ?>
                </div>
            </div>
        </nav>
        <nav class="navbar-mobile" id="nav-mobile" >
            <div class="container">
                <div class="navbar-header">
                    
                    <div class="header-nav">
		<ul class="clearfix" id="nav_menu">
            <li><a href="<?php $this->options->siteUrl(); ?>">首页</a></li>
             <?php $this->widget('Widget_Contents_Page_List')
                        ->parse('<li><a href="{permalink}">{title}</a></li>'); ?>
            <div style="font-size:10px;"><a href="javascript:void(0);" class="theme-switch"><i class="fa fa-adjust" aria-hidden="true"></i></a></div>
             
        </ul>
	<div> 

    </div>
                </div>
            </div>
        </nav>
<main class="main">
<div class="container">
  
      