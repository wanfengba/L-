/*
*文章道具
*/

//图片集
$('.article-collapse .collapse-head').on('click', function () {     
    let next = $(this).next();
    next.slideToggle(200);
    $('.article-collapse .collapse-body').not(next).slideUp();
});

$('.article-tabs .nav span').on('click', function () {
    let panel = $(this).attr('data-panel');
    $(this).addClass('active').siblings().removeClass('active');
    $(this).parents('.article-tabs').find('.tab-content div').hide();
    $(this)
    .parents('.article-tabs')
    .find('.tab-content div[data-panel=' + panel + ']')
    .show();
});

$.each($("div.song figure:not(.size-parsed)"), function(t, n) {
			var a = new Image;
			a.onload = function() {
				var t = parseFloat(a.width),
					e = parseFloat(a.height);
				$(n).addClass("size-parsed"), $(n).css("width", t + "px"), $(n).css("flex-grow", 50 * t / e), $(n).find("a").css("padding-top", e / t * 100 + "%")
			}, a.src = $(n).find("img").attr("src")
		});
//tab
function openCity(evt, cityName) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(cityName).style.display = "block";
    evt.currentTarget.className += " active";
}

//手风琴
$(".test-hide .tplus-div-title").click(function(){$(this.nextSibling).toggle(300);});

//点击自动删除
$("test-del").click(function(){$(this).remove();});

//点击加载更多
jQuery(document).ready(function($) {
    //点击下一页的链接(即那个a标签)
    $('.next').click(function() {
        $this = $(this);
        $this.addClass('loading').text('正在努力加载'); //给a标签加载一个loading的class属性，用来添加加载效果
        var href = $this.attr('href'); //获取下一页的链接地址
        if (href != undefined) { //如果地址存在
            $.ajax({ //发起ajax请求
                url: href,
                //请求的地址就是下一页的链接
                type: 'get',
                //请求类型是get
                error: function(request) {
                    //如果发生错误怎么处理
                },
                success: function(data) { //请求成功
                    $this.removeClass('loading').text('点击查看更多'); //移除loading属性
                    var $res = $(data).find('.article'); //从数据中挑出文章数据，请根据实际情况更改
                    $('.content').append($res.fadeIn(500)); //将数据加载加进posts-loop的标签中。
                    var newhref = $(data).find('.next').attr('href'); //找出新的下一页链接
                    if (newhref != undefined) {
                        $('.next').attr('href', newhref);
                    } else {
                        $('.next').remove(); //如果没有下一页了，隐藏
                    }
                }
            });
        }
        return false;
    });
});
jQuery(document).ready(function($){
	var isLateralNavAnimating = false;
	
	//open/close lateral navigation
	$('.cd-nav-trigger').on('click', function(event){
		event.preventDefault();
		//stop if nav animation is running 
		if( !isLateralNavAnimating ) {
			if($(this).parents('.csstransitions').length > 0 ) isLateralNavAnimating = true; 
			
			$('body').toggleClass('navigation-is-open');
			$('.cd-navigation-wrapper').one('webkitTransitionEnd otransitionend oTransitionEnd msTransitionEnd transitionend', function(){
				//animation is over
				isLateralNavAnimating = false;
			});
		}
	});
});