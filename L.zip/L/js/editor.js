function insertAtCursor(myField, myValue) {
    var textTop = myField.scrollTop;
    var documentTop = document.documentElement.scrollTop;

    //IE 浏览器
    if (document.selection) {
        myField.focus();
        var sel = document.selection.createRange();
        sel.text = myValue;
        sel.select();
    }

    //FireFox、Chrome等
    else if (myField.selectionStart || myField.selectionStart == '0') {
        var startPos = myField.selectionStart;
        var endPos = myField.selectionEnd;
        myField.value = myField.value.substring(0, startPos) + myValue + myField.value.substring(endPos, myField.value.length);
        myField.focus();
        myField.selectionStart = startPos + myValue.length;
        myField.selectionEnd = startPos + myValue.length;
    } else {
        myField.value += myValue;
        myField.focus();
    }

    myField.scrollTop = textTop;
    document.documentElement.scrollTop = documentTop;
}
$(function() {
    if($('#wmd-button-row').length>0){
       $('#wmd-button-row').append('<li class="wmd-button" id="wmd-sj-button" style="" title="插入首行缩进">' +'<svg class="icon" aria-hidden="true"><use xlink:href="#icon-suoqi"></use></svg>' +'</li>');
       $('#wmd-button-row').append('<li class="wmd-button" id="wmd-sc-button" style="" title="插入删除线">' +'<svg class="icon" aria-hidden="true"><use xlink:href="#icon-shanchuxian"></use></svg>' +'</li>');
        $('#wmd-button-row').append('<li class="wmd-button" id="wmd-zt-button" style="" title="插入颜色文字">' +'<svg class="icon" aria-hidden="true"><use xlink:href="#icon-ziti"></use></svg>' +'</li>');
        $('#wmd-button-row').append('<li class="wmd-button" id="wmd-wztest-button" style="" title="插入自动删除">' +'<svg class="icon" aria-hidden="true"><use xlink:href="#icon-daima"></use></svg>' +'</li>');
        $('#wmd-button-row').append('<li class="wmd-button" id="wmd-lg-button" style="" title="插入流光文字">' +'<svg class="icon" aria-hidden="true"><use xlink:href="#icon-liuguang-kai"></use></svg>' +'</li>');
        $('#wmd-button-row').append('<li class="wmd-button" id="wmd-bl-button" style="" title="插入毛玻璃">' +'<svg class="icon" aria-hidden="true"><use xlink:href="#icon-boli1"></use></svg>' +'</li>');
        $('#wmd-button-row').append('<li class="wmd-button" id="wmd-hm-button" style="" title="插入黑幕">' +'<svg class="icon" aria-hidden="true"><use xlink:href="#icon-danmu"></use></svg>' +'</li>');
         $('#wmd-button-row').append('<li class="wmd-button" id="wmd-tab-button" style="" title="插入tab">' +'<svg class="icon" aria-hidden="true"><use xlink:href="#icon-tab"></use></svg>' +'</li>');
        $('#wmd-button-row').append('<li class="wmd-button" id="wmd-bili-button" style="" title="插入B站视频">' +'<svg class="icon" aria-hidden="true"><use xlink:href="#icon-bilibili"></use></svg>' +'</li>');
        $('#wmd-button-row').append('<li class="wmd-button" id="wmd-wangyiyun-button" style="" title="插入网易云音乐">' +'<svg class="icon" aria-hidden="true"><use xlink:href="#icon-wangyiyinle"></use></svg>' +'</li>');
         $('#wmd-button-row').append('<li class="wmd-button" id="wmd-hf-button" style="" title="插入回复可见">' +'<svg class="icon" aria-hidden="true"><use xlink:href="#icon-bukejian"></use></svg>' +'</li>');
        $('#wmd-button-row').append('<li class="wmd-button" id="wmd-dl-button" style="" title="插入登录可见">' +'<svg class="icon" aria-hidden="true"><use xlink:href="#icon-denglu"></use></svg>' +'</li>');
        $('#wmd-button-row').append('<li class="wmd-button" id="wmd-cid-button" style="" title="插入文章卡片">' +'<svg class="icon" aria-hidden="true"><use xlink:href="#icon-shangpintuiguang"></use></svg>' +'</li>');
        $('#wmd-button-row').append('<li class="wmd-button" id="wmd-jdt-button" style="" title="插入进度条">' +'<svg class="icon" aria-hidden="true"><use xlink:href="#icon-jindutiao"></use></svg>' +'</li>');

        
        $(document).on('click','#wmd-sj-button',function() {
            myField = document.getElementById('text');
            insertAtCursor(myField, '&emsp;&emsp;');
        });
         $(document).on('click','#wmd-lg-button',function() {
            myField = document.getElementById('text');
            insertAtCursor(myField, '\n[lgwz]流光内容[/lgwz]\n');
        });

        $(document).on('click','#wmd-sc-button',function() {
            myField = document.getElementById('text');
            insertAtCursor(myField, '\n~~内容~~\n');
        });
        $(document).on('click','#wmd-parseCollapse-button',function() {
            myField = document.getElementById('text');
            insertAtCursor(myField, '\n[collapse label="标题"\]内容\[\/collapse\]\n');
        });
        $(document).on('click','#wmd-bili-button',function() {
            myField = document.getElementById('text');
            insertAtCursor(myField, '\n[bilibili bv="" p="1"]\n');
        });
        $(document).on('click','#wmd-bl-button',function() {
            myField = document.getElementById('text');
            insertAtCursor(myField, '\n[mbl]要藏起来的···[/mbl]\n');
        });
        $(document).on('click','#wmd-hm-button',function() {
            myField = document.getElementById('text');
            insertAtCursor(myField, '\n[darkb-text]看不见的···[/darkb-text]\n');
        });
        $(document).on('click','#wmd-wangyiyun-button',function() {
            myField = document.getElementById('text');
            insertAtCursor(myField, '\n[mp3]输入网易云音乐id[/mp3]\n');
        });
        $(document).on('click', '#wmd-dl-button', function () {
            myField = document.getElementById('text');
            insertAtCursor(myField, '\n[login]此处内容需要回复可见[/login]\n');
        });
        $(document).on('click', '#wmd-hf-button', function () {
            myField = document.getElementById('text');
            insertAtCursor(myField, '\n[hide]此处内容登入可见[/hide]\n');
        });
       $(document).on('click', '#wmd-ggg-button', function () {
            myField = document.getElementById('text');
            insertAtCursor(myField, '\n[div class="article-photos"]\n\n[/div]\n');
        });
        $(document).on('click', '#wmd-jdt-button', function () {
            myField = document.getElementById('text');
            insertAtCursor(myField, '\n[jdt jd="进度" color="颜色"]内容[/jdt]\n');
        });
        $(document).on('click', '#wmd-fed-button', function () {
            myField = document.getElementById('text');
            insertAtCursor(myField, '\n[fed]内容[/fed]\n');
        });
        $(document).on('click', '#wmd-cid-button', function () {
            myField = document.getElementById('text');
            insertAtCursor(myField, '\n[cid="此处插入文章的cid"]\n');
        });
        $(document).on('click', '#wmd-wztest-button', function () {
            myField = document.getElementById('text');
            insertAtCursor(myField, '[test-del]自动删除文字[/test-del]\n');
        });
        $(document).on('click', '#wmd-photo-button', function () {
            myField = document.getElementById('text');
            insertAtCursor(myField, '\n[photos]\n\n[/photos]\n');
        });
        

        $(document).on('click', '#wmd-youqing-button', function () {
            myField = document.getElementById('text');
            insertAtCursor(myField, '\n!!!\n[links]\n[名称][网址](头像)\n[/links]\n!!!\n');
        });
        $(document).on('click', '#wmd-zt-button', function() {

            $('body').append(
                '<div id="TPanel">'+
                '<div class="wmd-prompt-background" style="position: fixed; top: 0px; z-index: 1000; opacity: 0.5; height: 100%; left: 0px; width: 100%;"></div>'+
                '<div class="wmd-prompt-dialog">'+
                '<div>'+
                '<p><b>文字样式自定义</b></p>'+
                '<p><labe>输入文字颜色</labe><input name="color"' +
                ' type="text" placeholder="选填（如 #ffffff 、red）"></input></p>' +
                ' <p><labe>输入文字内容</labe><textarea type="text"/></p>'+
                '</div>'+
                '<form>'+
                '<button type="button" class="btn btn-s primary" id="t_ok">确定</button>'+
                '<button type="button" class="btn btn-s" id="t_cancel">取消</button>'+
                '</form>'+
                '</div>'+
                '</div>');

        });
        

        $(document).on('click', '#wmd-tab-button', function() {

            textContent = '[tabs]\n' +
                '[tab-pane label="标签页 1"]内容 1[/tab-pane]\n' +
                '[tab-pane label="标签页 2"]内容 2[/tab-pane]\n' +
                '[/tabs]';

            myField = document.getElementById('text');
            inserContentToTextArea(myField,textContent);

        });

        
        $(document).on('click','#t_ok',function() {
            //执行一个ajax请求获取解析歌单地址的音频信息
            myField = document.getElementById('text');
            var content = $('.wmd-prompt-dialog textarea').val();
            var color = $('.wmd-prompt-dialog input[name = "color"]').val();
            if (color!=""){
                color = ' '+color+'';
            }
            var insertContent = "";
            if ($("#isCenter").is(':checked')){
                insertContent = '<p class="center"'+color+'>'+content+'</p>';
            }else{
                insertContent = '[colour type="'+color+'"]'+content+'[/colour]';
            }

            inserContentToTextArea(myField,insertContent,'#TPanel');

        });

       

        $(document).on('click','#ss_ok',function() {//收缩框

            var obj_ty = document.getElementById("sst"); //定位id
            var index_ty = obj_ty.selectedIndex; // 选中索引
            var type = obj_ty.options[index_ty].value; // 选中值
            var t = $('.wmd-prompt-dialog input[name="bt"]').val();
//输出格式
            textContent = '[collapse status="' + type + '" label="' + t + '"]这里编辑收缩框内容[/collapse]';

            myField = document.getElementById('text');
            inserContentToTextArea(myField,textContent,'#ssPanel');//收缩框

        });
        
        $(document).on('click','#xx_ok',function() {//信息提示框

            var obj_ty = document.getElementById("sst"); //定位id
            var index_ty = obj_ty.selectedIndex; // 选中索引
            var type = obj_ty.options[index_ty].value; // 选中值
            var t = $('.wmd-prompt-dialog input[name="bt"]').val();
//输出格式
            textContent = '[div class="' + type + '"]这里编辑提示信息内容[/div]';

            myField = document.getElementById('text');
            inserContentToTextArea(myField,textContent,'#xxPanel');//收缩框

        });
  
        $(document).on('click','#button_cancel',function() {//按钮
            $('#buttonPanel').remove();//按钮
            $('textarea').focus();
        });
      
    }
});

//插入内容到编辑器
function inserContentToTextArea(myField,textContent,modelId) {
    $(modelId).remove();
    if (document.selection) {//IE浏览器
        myField.focus();
        var sel = document.selection.createRange();
        sel.text = textContent;
        myField.focus();
    } else if (myField.selectionStart || myField.selectionStart == '0') {
        //FireFox、Chrome
        var startPos = myField.selectionStart;
        var endPos = myField.selectionEnd;
        var cursorPos = startPos;
        myField.value = myField.value.substring(0, startPos)
            + textContent
            + myField.value.substring(endPos, myField.value.length);
        cursorPos += textContent.length;

        myField.selectionStart = cursorPos;
        myField.selectionEnd = cursorPos;
        myField.focus();
    }
    else{//其他环境
        myField.value += textContent;
        myField.focus();
    }

    //开启粘贴上传图片

}


!function(e){var t,n,o,i,d,l,c='<svg><symbol id="icon-boli" viewBox="0 0 1024 1024"><path d="M837.818182 1024H0V0h837.818182v1024zM46.545455 977.454545h744.727272V46.545455H46.545455v930.90909z m977.454545-46.545454H791.272727V93.090909h232.727273v837.818182z m-186.181818-46.545455h139.636363V139.636364h-139.636363v744.727272zM225.908364 598.272l-32.907637-32.907636 418.909091-418.909091 32.907637 32.907636z m0 279.272727l-32.907637-32.907636 418.909091-418.909091 32.907637 32.907636z" fill="#817FD1" ></path></symbol><symbol id="icon-saomahexiao" viewBox="0 0 1024 1024"><path d="M161.792 481.792h699.904v59.904H161.792V481.792z m640 320H222.208v-175.104H161.792v235.008h699.904v-235.008h-59.904v175.104z m-640-640v235.008h59.904V222.208h580.096v175.104h59.904v-235.52H161.792z"  ></path></symbol></svg>',a=(a=document.getElementsByTagName("script"))[a.length-1].getAttribute("data-injectcss");if(a&&!e.__iconfont__svg__cssinject__){e.__iconfont__svg__cssinject__=!0;try{document.write("<style>.svgfont {display: inline-block;width: 1em;height: 1em;fill: currentColor;vertical-align: -0.1em;font-size:16px;}</style>")}catch(e){console&&console.log(e)}}function s(){d||(d=!0,o())}t=function(){var e,t,n;(n=document.createElement("div")).innerHTML=c,c=null,(t=n.getElementsByTagName("svg")[0])&&(t.setAttribute("aria-hidden","true"),t.style.position="absolute",t.style.width=0,t.style.height=0,t.style.overflow="hidden",e=t,(n=document.body).firstChild?(t=n.firstChild).parentNode.insertBefore(e,t):n.appendChild(e))},document.addEventListener?~["complete","loaded","interactive"].indexOf(document.readyState)?setTimeout(t,0):(n=function(){document.removeEventListener("DOMContentLoaded",n,!1),t()},document.addEventListener("DOMContentLoaded",n,!1)):document.attachEvent&&(o=t,i=e.document,d=!1,(l=function(){try{i.documentElement.doScroll("left")}catch(e){return void setTimeout(l,50)}s()})(),i.onreadystatechange=function(){"complete"==i.readyState&&(i.onreadystatechange=null,s())})}(window);