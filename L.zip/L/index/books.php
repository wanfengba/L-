 <div class="post">
   <article class="index-post">
       <div style="display: flex;justify-content: space-between;">
        <a class="index_title" href="<?php $this->permalink() ?>" style="
        text-decoration: none;
        letter-spacing: 1px;
        font-size: 1.5rem;
        margin-bottom: 0.5pc;">
           <div class="tooltip"><?php $this->title() ?><span class="tooltiptext">这里是书单</span></div> 
        </a> <!-- 文章标题 -->
        <span style="
        font-size: 12px;
        font-weight: 400;
        align-items: center;
        margin-bottom: 1pc;">
            <?php $this->date('Y年m月d日'); ?><!-- 文章时间 -->
        </span>
       </div>
    </article>
    
    <article id="index-post">
       <div style="display: flex;flex-direction: column;">
        <a class="index_title" href="<?php $this->permalink() ?>" style="
        text-decoration: none;
        letter-spacing: 1px;
        font-size: 1.5rem;
        margin-bottom: 0.5pc;">
           <div class="tooltip"><?php $this->title() ?><span class="tooltiptext">这里是书单</span></div> 
        </a> <!-- 文章标题 -->
        <span style="
        padding-top: 10px;
        font-size: 12px;
        font-weight: 400;
        align-items: center;
        margin-bottom: 1pc;">
            <?php $this->date('Y年m月d日'); ?><!-- 文章时间 -->
        </span>
      </div>
      </div>
    </article>
    
    <style>
    .tooltip {
    position: relative;
    display: inline-block;
    border-bottom: 1px dotted black;
}

.tooltip .tooltiptext {
    visibility: hidden;
    width: 120px;
    background-color: #555;
    color: #fff;
    text-align: center;
    border-radius: 6px;
    padding: 5px 0;
    position: absolute;
    z-index: 1;
    bottom: 125%;
    left: 50%;
    margin-left: -60px;
    opacity: 0;
    transition: opacity 1s;
}

.tooltip .tooltiptext::after {
    content: "";
    position: absolute;
    top: 100%;
    left: 50%;
    margin-left: -5px;
    border-width: 5px;
    border-style: solid;
    border-color: #555 transparent transparent transparent;
}

.tooltip:hover .tooltiptext {
    visibility: visible;
    opacity: 1;
}
    </style>