<?php if (!defined( '__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->footer(); ?>
</div>
</main>
<footer class="footer">
<script src="https://cdn.jsdelivr.net/gh/wanfengba/tuping/prism.js"></script>
<script src="https://cdn.jsdelivr.net/gh/wanfengba/tuping/jquery.lighter.js"></script><!--灯箱-->
<script src='<?php $this->options->themeUrl('js/jquery.min.js'); ?>'></script><!--灯箱-->
<script src="<?php $this->options->themeUrl('OwO/OwO.min.js'); ?>"></script>
<script src='<?php $this->options->themeUrl('js/main.js'); ?>'></script>
<script>
      var OwO_demo = new OwO({
        logo: 'OωO表情',
        container: document.getElementsByClassName('OwO')[0],
        target: document.getElementsByClassName('OwO-textarea')[0],
        api: '<?php $this->options->themeUrl('OwO/OwO.json'); ?>',
        position: 'down',
        width: '100%',
        maxHeight: '250px'
    });
</script>
<script>window.dataLayer =window.dataLayer ||[];function gtag(){dataLayer.push(arguments);}
gtag('js',new Date());gtag('config','UA-110780416-1');</script>
</footer>
<!---->
<script>

</script>
<!-- Resource jQuery -->
<script src='<?php $this->options->themeUrl('js/nprogress.js'); ?>'></script><!--缓冲线-->
<script src='<?php $this->options->themeUrl('js/vendor_main.min.js'); ?>'></script><!--夜间-->
<script src='<?php $this->options->themeUrl('js/pjax.min.js'); ?>'></script><!--pajx-->
<script>
var pjax = new Pjax({
    elements: 'a[href]:not([href^="#"])',
    cacheBust: false,
    debug: false,
    selectors: ['title', '.wrapper'
    ]
});
document.addEventListener('pjax:send', function () {
    NProgress.start();
});
document.addEventListener('pjax:complete', function () {
    NProgress.done();
});
</script>
<!--pjax-->

<!--评论-->
<script>
// 依赖jquery,请自行加载
$(function(){
    // 监听评论表单提交
    $('#comment-form').submit(function(){
        var form = $(this), params = form.serialize();
        // 添加functions.php中定义的判断参数
        params += '&themeAction=comment';
        
        // 解析新评论并附加到评论列表
        var appendComment = function(comment){
            // 评论列表
            var el = $('#comments > .comment-list');
            if(0 != comment.parent){
                // 子评论则重新定位评论列表
                var el = $('#comment-'+comment.parent);
                // 父评论不存在子评论时
                if(el.find('.comment-children').length < 1){
                    $('<div class="comment-children"><ol class="comment-list"></ol></div>').appendTo(el);
                }else if(el.find('.comment-children > .comment-list').length <1){
                    $('<ol class="comment-list"></ol>').appendTo(el.find('.comment-children'));
                }
                el = $('#comment-'+comment.parent).find('.comment-children').find('.comment-list');
            }
            if(0 == el.length){
                $('<ol class="comment-list"></ol>').appendTo($('#comments'));
                el = $('#comments > .comment-list');
            }
                        // 评论html模板，根据具体主题定制
            var html = '<li id="comment-{coid}" class="comment-body comment-ajax"><div class="comment-author"><span><img class="avatar" src="{avatar}" alt="{author}" width="32" height="32"></span><cite class="fn">{author}</cite></div><div class="comment-meta"><a href="{permalink}"><time>{datetime}</time></a></div><div class="comment-content">{content}</div></li>';
            $.each(comment,function(k,v){
                regExp = new RegExp('{'+k+'}', 'g');
                html = html.replace(regExp, v);
            });
            $(html).appendTo(el);
        }
        // ajax提交评论
        $.ajax({
            url: '<?php $this->permalink();?>',
            type: 'POST',
            data: params,
            dataType: 'json',
            beforeSend: function() { form.find('.submit').addClass('loading').html('<i class="icon icon-loading icon-pulse"></i> 提交中...').attr('disabled','disabled');},
            complete: function() { form.find('.submit').removeClass('loading').html('提交评论').removeAttr('disabled');},
            success: function(result){
                if(1 == result.status){
                    // 新评论附加到评论列表
                    appendComment(result.comment);
                    form.find('textarea').val('');
                }else{
                    // 提醒错误消息
                    alert(undefined === result.msg ? '<?php _e('评论出错!');?>' : result.msg);
                }
            },
            error:function(xhr, ajaxOptions, thrownError){
                alert('评论失败，请重试');
            }
        });
        return false;
    });
    </script>

</body>

</html>