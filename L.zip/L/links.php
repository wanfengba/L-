<?php 
/**
* 友链
*
* @package custom
*/
if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>
<article class="post-warp">
    <header class="post-header">
        <div class="header_img"><img src="<?php $this->options->toutu(); ?>"></div>
       
    <div class="post-meta">
        
        <div class="post_title" style="display: flex;">
                        <h1><?php $this->title() ?></h1>   
                        <span style="font-size: x-small;
                                     margin-left: 5px;"><?php get_post_view($this) ?> 阅读</span>
                    </div>
        
    </div>
    </header>
        <div class="page-content">
                <?php $this->content(); ?>
         </div>
                
    
                     <div class="links">
                      <div class="row">

                       <?php Links(); ?>

                          </div>
                      </div>
    
</article>
<?php $this->need('comments.php'); ?>
<?php $this->need('footer.php'); ?>




<style>
.row {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    
}
.row > div {
    margin-bottom: 10px;
    margin-top: 10px;
}


.col-md-4{position: relative;
    width: 50%;
    min-height: 1px;
    padding-right: 5px;
   
}
@media screen and (max-width: 510px){.col-md-4{position: relative;
    width: 100%;
    min-height: 1px;
    padding-right: 15px;
    padding-left: 15px;
}}
.card {
    position: relative;
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -ms-flex-direction: column;
    flex-direction: row;
    min-width: 0;
    word-wrap: break-word;
    background-clip: border-box;
    border-radius: .25rem;
}
.card-img-top {
    padding: 1pc;
    width: 60px;
    border-top-left-radius: calc(.25rem - 1px);
    border-top-right-radius: calc(.25rem - 1px);
}
.card-body {
    -webkit-box-flex: 1;
    -ms-flex: 1 1 auto;
    flex: 1 1 auto;
    padding: 10px;
    font-size: xx-small;
}
.card-title {
    margin-bottom: .75rem;
}
.btn:not(:disabled):not(.disabled) {
    cursor: pointer;
}
.btn-primary {
    color: #fff;
    background-color: #007bff;
    border-color: #007bff;
}
/*文本超出显示省略号*/
p.card-text{
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 1;
    overflow: hidden;
}

</style>